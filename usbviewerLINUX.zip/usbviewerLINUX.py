
def usb():
    import os
    import time
    
    print('loading...')
    time.sleep(3)
    os.system('clear')
    
    
    os.system('lsusb')
    time.sleep(1000000)






usb()

